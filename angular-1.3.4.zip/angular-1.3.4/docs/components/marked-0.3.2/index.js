module.exports = require('./lib/marked');
